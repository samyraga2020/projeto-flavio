const SearchActionTypes = {
  SET_SEARCH_DATA: 'SET_SEARCH_DATA',
};

export default SearchActionTypes;